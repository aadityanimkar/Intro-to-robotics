# iiwa_description

Urdf description for the Kuka iiwa 7 R800 and iiwa 14 R820.
Extracted and adapted from https://github.com/IFL-CAMP/iiwa_stack
